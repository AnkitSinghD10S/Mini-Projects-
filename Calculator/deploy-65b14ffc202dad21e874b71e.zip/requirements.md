# Calulator requirements

-> Java Script
function

->css
Colors
flexbox 

->HTML
tags
id